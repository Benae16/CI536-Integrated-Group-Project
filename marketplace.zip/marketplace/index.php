<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" 
        content="width=device-width, initial-scale=1.0">
  <title>Simple Website</title>
  <link rel="stylesheet" href="/marketplace/css/style.css">
</head>
<body>
  <header>
    <h1>Welcome to the Brighton Student Marketplace </h1>
  </header>

  <nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="listings.php">Listings</a></li>
      <li><a href="add_listing.php">Create Listing MOVE THIS</a></li>
      <li><a href="social.php">Social</a></li>
      <li><a href="profile.php">Profile</a></li>
      <li><a href="login.php">Log In / Sign Up</a></li>
    </ul>
  </nav>

  <main>
    <section id="home">
        <h2>Home</h2>
        <p>
            Welcome to our website! 
            We are a passionate team dedicated to 
            providing the best marketplace paltform we can
            for our fellow students. You can access the marketplace
            by heading over to the "Listings" section and
            if you go to the "Social" section you can
            create and customise your profile to find
            your friends or other students! </p>
    </section>

    <section id="about">
        <h2>Listings</h2>
        <p>
            xyz
        </p>
    
      </section>

    <section id="services">
      <h2>Social</h2>
      <p>
            This is the social section of the site.
      </p>
    </section>

    <section id="contact">
        <h2>Profile</h2>
        <p>
            xyz
        </p>
      </section>
  </main>

  <footer>
    <p>&copy; 2025 xyz. All rights reserved.</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>