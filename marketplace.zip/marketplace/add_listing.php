<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $user_id = $_SESSION['user_id'];
    $image_paths = [];

    $target_dir = "uploads/";
    $allowed_types = ["jpg", "jpeg", "png", "gif"];

    foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
        if (!empty($_FILES["images"]["name"][$key])) {
            $image_name = basename($_FILES["images"]["name"][$key]);
            $target_file = $target_dir . time() . "_" . $image_name;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            if (in_array($imageFileType, $allowed_types)) {
                if (move_uploaded_file($_FILES["images"]["tmp_name"][$key], $target_file)) {
                    $image_paths[] = $target_file;
                }
            }
        }
    }

    $image_paths_str = implode(",", $image_paths);

    $stmt = $conn->prepare("INSERT INTO Listings (User_ID, Title, Description, Price, Category, Images) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issdss", $user_id, $title, $description, $price, $category, $image_paths_str);

    if ($stmt->execute()) {
        header("Location: listings.php");
        exit();
    } else {
        $error = "Error adding listing.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Listing - Buy Bright</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F3E8FF;
            margin: 0;
            padding: 0;
        }

        .container {
            background-color: white;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 572px;
            width: 100%;
            margin: 2rem auto;
        }

        h1 {
            text-align: center;
            font-size: 1.875rem;
            font-weight: 600;
            color: #111827;
            margin-bottom: 1rem;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        input, select, textarea {
            width: 100%;
            padding: 0.625rem 0.875rem;
            font-size: 1rem;
            border: 1px solid #D1D5DB;
            border-radius: 0.5rem;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
        }

        button {
            padding: 0.625rem 1.25rem;
            font-size: 1rem;
            font-weight: 600;
            color: white;
            background-color: #8B5CF6;
            border: none;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        button:hover {
            background-color: #7C3AED;
        }

        .error {
            color: #dc2626;
            font-size: 0.875rem;
            text-align: center;
        }

        /* Image Preview */
        #imagePreviewContainer {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }

        .image-preview {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .image-preview img {
            max-width: 120px;
            height: auto;
            border-radius: 8px;
            transition: transform 0.2s;
        }

        .image-preview img:hover {
            transform: scale(1.1);
        }

        .remove-btn {
            position: absolute;
            top: 2px;
            right: 2px;
            background-color: red;
            color: white;
            border: none;
            padding: 5px;
            font-size: 0.75rem;
            cursor: pointer;
            border-radius: 50%;
        }

        .remove-btn:hover {
            background-color: darkred;
        }

        /* Image Popup */
        #imagePopup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        #popupImage {
            max-width: 90%;
            max-height: 90%;
            border-radius: 8px;
        }

        #closePopup {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 24px;
            color: white;
            cursor: pointer;
        }
        /* ===== Navigation ===== */
        nav {
            background-color: #8B5CF6; /* Purple background for nav */
            padding: 1rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            gap: 1.5rem; /* Space between nav items */
        }

        nav li {
            display: inline-block;
        }

        nav a {
            color: #fff; /* White text for nav links */
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 4px; /* Rounded corners for nav links */
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #7C3AED; /* Darker purple on hover */
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="listings.php">Listings</a></li>
            <li><a href="social.php">Social</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="login.php">Log In</a></li>
            <li><a href="register.php">Sign Up</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>Add a Listing</h1>

        <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="add_listing.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="title" placeholder="Item Title" required>
            <textarea name="description" placeholder="Item Description" rows="4" required></textarea>
            <input type="number" step="0.01" name="price" placeholder="Price (£)" required>

            <select name="category" required>
                <option value="">-- Select Category --</option>
                <option value="Books">Books</option>
                <option value="Electronics">Electronics</option>
                <option value="Furniture">Furniture</option>
                <option value="Clothing">Clothing</option>
                <option value="Other">Other</option>
            </select>

            <input type="file" name="images[]" id="imageUpload" accept="image/*" multiple onchange="previewImages(event)">

            <div id="imagePreviewContainer"></div>

            <button type="submit">Post Listing</button>
        </form>
    </div>

    <div id="imagePopup">
        <span id="closePopup">&times;</span>
        <img id="popupImage" src="" alt="Full Image">
    </div>

    <script>
        function previewImages(event) {
            var fileInput = event.target;
            var previewContainer = document.getElementById('imagePreviewContainer');
            previewContainer.innerHTML = "";

            Array.from(fileInput.files).forEach((file, index) => {
                var reader = new FileReader();

                reader.onload = function(e) {
                    var previewDiv = document.createElement("div");
                    previewDiv.classList.add("image-preview");
                    previewDiv.innerHTML = `
                        <img src="${e.target.result}" alt="Image Preview" onclick="openPopup('${e.target.result}')">
                    `;
                    previewContainer.appendChild(previewDiv);
                };

                reader.readAsDataURL(file);
            });
        }

        function openPopup(src) {
            document.getElementById("popupImage").src = src;
            document.getElementById("imagePopup").style.display = "flex";
        }

        document.getElementById("closePopup").addEventListener("click", function() {
            document.getElementById("imagePopup").style.display = "none";
        });
    </script>
</body>
</html>
