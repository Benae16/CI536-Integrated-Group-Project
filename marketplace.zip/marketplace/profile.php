<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    die("You must be logged in! <a href='login.php'>Login</a>");
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $conn->prepare("SELECT fName, sName, Email, University FROM Users WHERE User_ID = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($fName, $sName, $email, $university);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
</head>
<body>
    <h1>Profile</h1>
    <p><strong>Name:</strong> <?php echo $fName . " " . $sName; ?></p>
    <p><strong>Email:</strong> <?php echo $email; ?></p>
    <p><strong>University:</strong> <?php echo $university ?? "Not specified"; ?></p>
    <p><a href="edit_profile.php">Edit Profile</a></p> <!-- Optional: Add an edit profile page -->
</body>
</html>