<?php
include 'config.php';

// Fetch listings with seller's first name and surname
$result = $conn->query("SELECT Listings.*, Users.fName, Users.sName FROM Listings JOIN Users ON Listings.user_id = Users.User_ID ORDER BY Listings.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
</head>
<body>
    <h1>Marketplace</h1>
    <?php
    while ($row = $result->fetch_assoc()) {
        echo "<div>";
        echo "<h2>" . $row['title'] . "</h2>";
        echo "<p>By: " . $row['fName'] . " " . $row['sName'] . "</p>"; // Display full name
        echo "<p>" . $row['description'] . "</p>";
        echo "<p>Price: $" . $row['price'] . "</p>";
        echo "<img src='uploads/" . $row['image'] . "' width='100'>";
        echo "</div><hr>";
    }
    ?>
</body>
</html>