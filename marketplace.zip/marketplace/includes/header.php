<nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="listings.php">Listings</a></li>
            <li><a href="social.php">Social</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="login.php">Log In</a></li>
            <li><a href="register.php">Sign Up</a></li>
        </ul>
    </nav>