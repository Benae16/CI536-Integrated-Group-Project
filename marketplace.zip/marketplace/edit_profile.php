<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    die("You must be logged in! <a href='login.php'>Login</a>");
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fName = $_POST['fName'];
    $sName = $_POST['sName'];
    $university = $_POST['university'];

    $stmt = $conn->prepare("UPDATE Users SET fName = ?, sName = ?, University = ? WHERE User_ID = ?");
    $stmt->bind_param("sssi", $fName, $sName, $university, $user_id);

    if ($stmt->execute()) {
        echo "Profile updated successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}

// Fetch current user details
$stmt = $conn->prepare("SELECT fName, sName, University FROM Users WHERE User_ID = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($fName, $sName, $university);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
</head>
<body>
    <h1>Edit Profile</h1>
    <form method="post">
        <input type="text" name="fName" placeholder="First Name" value="<?php echo $fName; ?>" required>
        <input type="text" name="sName" placeholder="Surname" value="<?php echo $sName; ?>" required>
        <input type="text" name="university" placeholder="University" value="<?php echo $university; ?>">
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>