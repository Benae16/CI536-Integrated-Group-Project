<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['fName']) || !isset($_POST['sName']) || !isset($_POST['email']) || !isset($_POST['password'])) {
        die("All required fields must be filled out.");
    }

    $fName = $_POST['fName'];
    $sName = $_POST['sName'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $university = isset($_POST['university']) ? $_POST['university'] : null;
    $profilePicture = "";

    $stmt = $conn->prepare("INSERT INTO Users (fName, sName, Email, Password_Hash, University, Profile_Picture) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $fName, $sName, $email, $password, $university, $profilePicture);

    if ($stmt->execute()) {
        // Set a success flag to trigger the modal
        $success = true;
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        /* ===== Navigation ===== */
        nav {
            background-color: #8B5CF6; /* Purple background for nav */
            padding: 1rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            gap: 1.5rem; /* Space between nav items */
        }

        nav li {
            display: inline-block;
        }

        nav a {
            color: #fff; /* White text for nav links */
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 4px; /* Rounded corners for nav links */
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #7C3AED; /* Darker purple on hover */
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #F3E8FF;
            margin: 0;
        }

        .container {
            background-color: white;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 572px;
            width: 100%;
            margin: 2rem auto; /* Center the container horizontally */
        }

        h1 {
            font-size: 1.875rem;
            font-weight: 600;
            color: #111827;
            margin-bottom: 2rem;
            text-align: center;
        }

        h2 {
            font-size: 1.575rem;
            font-weight: 600;
            color: #111827;
            margin-bottom: 2rem;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .input-group {
            display: flex;
            gap: 1rem;
        }

        @media (max-width: 640px) {
            .input-group {
                flex-direction: column;
            }
        }

        .input-group > div {
            flex: 1;
        }

        input, select {
            width: 100%;
            padding: 0.625rem 0.875rem;
            font-size: 1rem;
            color: #111827;
            background-color: white;
            border: 1px solid #D1D5DB;
            border-radius: 0.5rem;
            box-sizing: border-box;
        }

        select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236B7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 1rem;
        }

        button {
            padding: 0.625rem 1.25rem;
            font-size: 1rem;
            font-weight: 600;
            color: white;
            background-color: #8B5CF6;
            border: none;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        button:hover {
            background-color: #7C3AED;
        }

        .login-link {
            text-align: center;
            margin-top: 1rem;
        }

        .login-link a {
            color: #8B5CF6;
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        footer {
            font-size: 1rem;
            font-weight: 600;
            color: #111827;
            margin-bottom: 2rem;
            text-align: center;
        }

        /* Modal Styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5); /* Black with opacity */
        }

        .modal-content {
            background-color: #f3eadf;
            margin: 15% auto;
            padding: 1.25rem;
            border-radius: 0.5rem;
            width: 80%;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .modal-content p {
            font-size: 1.25rem;
            margin-bottom: 1.5rem;
        }

        .modal-content button {
            background-color: #f3eadf;
            color: white;
            border: none;
            padding: 0.625rem 1.25rem;
            border-radius: 0.25rem;
            cursor: pointer;
            font-size: 1rem;
        }

        .modal-content button:hover {
            background-color: #7C3AED;
        }
    </style>
</head>
<body>
    <header>
        <h1>Buy Bright</h1>
        <h2>Buy Right, Buy Bright</h2>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="listings.php">Listings</a></li>
            <li><a href="social.php">Social</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="login.php">Log In</a></li>
            <li><a href="register.php">Sign Up</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Sign Up</h1>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="input-group">
                <div>
                    <input type="text" name="fName" placeholder="First Name" required aria-label="First Name">
                </div>
                <div>
                    <input type="text" name="sName" placeholder="Last Name" required aria-label="Last Name">
                </div>
            </div>
            <div>
                <input type="email" name="email" placeholder="Email" required aria-label="Email">
            </div>
            <div>
                <input type="password" name="password" placeholder="Password" required aria-label="Password">
            </div>
            <div>
                <select name="university" aria-label="University">
                    <option value="">University (Optional)</option>
                    <option value="University of Brighton">University of Brighton</option>
                    <option value="University of Sussex">University of Sussex</option>
                    <option value="BIMM">BIMM</option>
                    <option value="BSMS">BSMS</option>
                </select>
            </div>
            <button type="submit">Submit</button>
        </form>
        <p class="login-link">Already have an account? <a href="login.php">Login here</a>.</p>
    </div>

    <!-- Modal for Success Message -->
    <div id="successModal" class="modal">
        <div class="modal-content">
            <p>User created successfully!</p>
            <button onclick="closeModal()">Close</button>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 bld. All rights reserved.</p>
    </footer>

    <script>
        // Function to show the modal
        function showModal() {
            document.getElementById('successModal').style.display = 'block';
        }

        // Function to close the modal
        function closeModal() {
            document.getElementById('successModal').style.display = 'none';
        }

        // Show the modal if the form was submitted successfully
        <?php if (isset($success) && $success): ?>
            showModal();
        <?php endif; ?>
    </script>
</body>
</html>