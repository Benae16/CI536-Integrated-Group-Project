<?php
$servername = "localhost";
$username = "bld27_market_user";  // Replace with your MySQL username
$password = "b?i0eE*oa)t]";      // Use the password you set in Step 2
$database = "bld27_marketplace";  // Replace with your actual database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
