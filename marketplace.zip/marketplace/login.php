<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare the SQL query
    $stmt = $conn->prepare("SELECT User_ID, Password_Hash FROM Users WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $hashed_password);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $user_id; // Store user ID in session

            // Redirect to index.php after successful login
            header("Location: index.php");
            exit(); // Ensure no further code is executed after the redirect
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "No user found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Buy Bright</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        /* ===== Global Styles ===== */
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F3E8FF; /* Light purple background */
            margin: 0;
            padding: 0;
        }

        h1, h2 {
            text-align: center;
            margin: 0;
        }

        h1 {
            font-size: 1.875rem;
            font-weight: 600;
            color: #111827; /* Dark text */
            margin-bottom: 1rem;
        }

        h2 {
            font-size: 1.575rem;
            font-weight: 600;
            color: #111827; /* Dark text */
            margin-bottom: 2rem;
        }

        /* ===== Navigation ===== */
        nav {
            background-color: #8B5CF6; /* Purple background for nav */
            padding: 1rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            gap: 1.5rem; /* Space between nav items */
        }

        nav li {
            display: inline-block;
        }

        nav a {
            color: #fff; /* White text for nav links */
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 4px; /* Rounded corners for nav links */
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #7C3AED; /* Darker purple on hover */
        }

        /* ===== Form Container ===== */
        .container {
            background-color: white;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 572px;
            width: 100%;
            margin: 2rem auto; /* Center the container horizontally */
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        input {
            width: 100%;
            padding: 0.625rem 0.875rem;
            font-size: 1rem;
            color: #111827; /* Dark text */
            background-color: white;
            border: 1px solid #D1D5DB; /* Light gray border */
            border-radius: 0.5rem;
            box-sizing: border-box;
        }

        input:focus {
            border-color: #8B5CF6; /* Purple border on focus */
            outline: none;
        }

        button {
            padding: 0.625rem 1.25rem;
            font-size: 1rem;
            font-weight: 600;
            color: white;
            background-color: #8B5CF6; /* Purple button */
            border: none;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        button:hover {
            background-color: #7C3AED; /* Darker purple on hover */
        }

        .login-link {
            text-align: center;
            margin-top: 1rem;
        }

        .login-link a {
            color: #8B5CF6; /* Purple link */
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        .error {
            color: #dc2626; /* Red for errors */
            font-size: 0.875rem;
            text-align: center;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Buy Bright</h1>
        <h2>Buy Right, Buy Bright</h2>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="listings.php">Listings</a></li>
            <li><a href="social.php">Social</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="login.php">Log In</a></li>
            <li><a href="register.php">Sign Up</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Log In</h1>
        <form method="post">
            <?php if (!empty($error)): ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            <div>
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit">Sign In</button>
            <p class="login-link">Don't have an account? <a href="register.php">Sign up here</a>.</p>
            <p class="login-link"><a href="forgot_password.php">Forgot password?</a></p>
        </form>
    </div>
</body>
</html>